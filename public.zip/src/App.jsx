import Nav from "./Nav";
import Sliding from "./Sliding";
import Img from "./Img";
import Contact from "./Contact";
function App() {
  return (
    <>
      <Nav />
      <Sliding />
      <Img />
      <Contact />
    </>
  );
}

export default App;
